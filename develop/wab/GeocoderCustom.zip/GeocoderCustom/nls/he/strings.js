﻿define(
   ({
    _widgetLabel: "מעגן כתובות",
    locationTitle: "מיקום",
    notFound: "לא ניתן למצוא את המיקום \'${LOCATION}\'",
    currentLocation: "המיקום הנוכחי",
    notWhatYouWanted: "זה לא מה שרצית?",
    selectAnother: "בחר מיקום אחר"
  })
);