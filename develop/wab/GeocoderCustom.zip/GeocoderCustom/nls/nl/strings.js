﻿define(
   ({
    _widgetLabel: "Geocoder",
    locationTitle: "Locatie",
    notFound: "Locatie '${LOCATION}' is niet gevonden.",
    currentLocation: "Huidige locatie",
    notWhatYouWanted: "Niet wat u wilde?",
    selectAnother: "Een andere locatie selecteren"
  })
);