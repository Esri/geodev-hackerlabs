﻿define(
   ({
    _widgetLabel: "Geocoder",
    locationTitle: "Position",
    notFound: "Die Position \'${LOCATION}\' konnte nicht gefunden werden.",
    currentLocation: "Aktuelle Position",
    notWhatYouWanted: "Nicht das gewünschte Ergebnis?",
    selectAnother: "Andere Position auswählen"
  })
);