﻿define(
   ({
    _widgetLabel: "Geokodeerija",
    locationTitle: "Asukoht",
    notFound: "Asukohta ${LOCATION} ei leitud.",
    currentLocation: "Praegune asukoht",
    notWhatYouWanted: "Ei ole see, mida soovisite?",
    selectAnother: "Valige mõni muu asukoht"
  })
);