﻿define(
   ({
    _widgetLabel: "Coğrafi Kodlayıcı",
    locationTitle: "Konum",
    notFound: "\'${LOCATION}\' konumu bulunamadı.",
    currentLocation: "Geçerli Konum",
    notWhatYouWanted: "İstediğiniz bu değil mi?",
    selectAnother: "Başka bir konum seç"
  })
);