﻿define(
   ({
    _widgetLabel: "Geocoder",
    locationTitle: "ตำแหน่ง",
    notFound: "ตำแหน่ง '${LOCATION}' ไม่พบ",
    currentLocation: "ตำแหน่งปัจจุบัน",
    notWhatYouWanted: "ไม่ใช่สิ่งที่คุณต้องการหรือ",
    selectAnother: "เลือกตำแหน่งอื่น"
  })
);