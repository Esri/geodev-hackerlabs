﻿define(
   ({
    _widgetLabel: "Геокодер",
    locationTitle: "Местоположение",
    notFound: "Местоположение '${LOCATION}' не найдено.",
    currentLocation: "Текущее местоположение",
    notWhatYouWanted: "Не то, что вы хотели?",
    selectAnother: "Выберите другое местоположение"
  })
);