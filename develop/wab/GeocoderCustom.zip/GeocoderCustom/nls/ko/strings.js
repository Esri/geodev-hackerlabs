﻿define(
   ({
    _widgetLabel: "지오코더",
    locationTitle: "위치",
    notFound: "'${LOCATION}' 위치를 찾을 수 없습니다.",
    currentLocation: "현재 위치",
    notWhatYouWanted: "원하는 위치가 아닙니까?",
    selectAnother: "다른 위치 선택"
  })
);