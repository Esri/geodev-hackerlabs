﻿define(
   ({
    _widgetLabel: "Trình mã hóa địa lý",
    locationTitle: "Vị trí",
    notFound: "Không thể tìm thấy vị trí '${LOCATION}'.",
    currentLocation: "Vị trí hiện tại",
    notWhatYouWanted: "Không phải là những gì bạn muốn?",
    selectAnother: "Chọn một vị trí khác"
  })
);