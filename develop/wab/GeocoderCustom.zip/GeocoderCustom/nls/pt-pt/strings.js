﻿define(
   ({
    _widgetLabel: "Geocodificador",
    locationTitle: "Localização",
    notFound: "Localização \'${LOCATION}\' não foi encontrada.",
    currentLocation: "Localização atual",
    notWhatYouWanted: "Não é o que pretende?",
    selectAnother: "Selecione outra localização"
  })
);