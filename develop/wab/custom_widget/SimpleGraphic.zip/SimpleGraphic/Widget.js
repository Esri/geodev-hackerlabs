define([
  'dojo/_base/declare',
  'jimu/BaseWidget',
  'esri/symbols/SimpleMarkerSymbol',
  "esri/graphic"
],
function() {
  
//insert code above
  clazz.hasStyle = false;
  clazz.hasUIFile = false;
  clazz.hasLocale = false;
  clazz.hasConfig = false;
  return clazz;
});