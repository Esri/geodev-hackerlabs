﻿define(
   ({
    _themeLabel: "Tema Dobrável",
    _layout_default: "Layout Padrão",
    _layout_layout1: "Layout 1"
  })
);