﻿define(
   ({
    _widgetLabel: "Contrôleur d’en-tête",
    signin: "Se connecter",
    signout: "Se déconnecter",
    about: "A propos",
    signInTo: "Se connecter à",
    cantSignOutTip: "Cette fonction est N/D en mode d’aperçu."
  })
);
