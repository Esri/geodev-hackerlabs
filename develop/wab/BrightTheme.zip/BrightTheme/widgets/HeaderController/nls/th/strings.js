﻿define(
   ({
    _widgetLabel: "ตัวควบคุมหัวข้อ",
    signin: "ลงชื่อเข้าใช้",
    signout: "ลงชื่อออก",
    about: "เกี่ยวกับ",
    signInTo: "ลงชื่อเข้าใช้สู่",
    cantSignOutTip: "ฟังก์ชันนี้ไม่มีในโหมดการแสดงตัวอย่าง"
  })
);
