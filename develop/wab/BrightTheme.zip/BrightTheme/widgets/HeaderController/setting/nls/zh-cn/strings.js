﻿define(
   ({
    group: "名称",
    openAll: "面板中的\“打开所有\”",
    dropDown: "在下拉菜单中显示",
    noGroup: "不存在微件组集。",
    groupSetLabel: "设置微件组属性"
  })
);