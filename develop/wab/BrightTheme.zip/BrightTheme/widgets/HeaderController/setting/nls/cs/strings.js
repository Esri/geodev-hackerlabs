﻿define(
   ({
    group: "Název",
    openAll: "Otevřít vše v panelu",
    dropDown: "Zobrazit v rozbalovací nabídce",
    noGroup: "Není nastavena žádná skupina widgetů.",
    groupSetLabel: "Nastavit vlastnosti skupin widgetů"
  })
);