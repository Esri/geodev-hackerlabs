﻿define(
   ({
    group: "Nume",
    openAll: "Deschidere toate din panou",
    dropDown: "Afişare în meniu derulant",
    noGroup: "Nu este setat niciun grup de widgeturi.",
    groupSetLabel: "Setare proprietăţi pentru grupuri de widgeturi"
  })
);