define({
  "_themeLabel": "Salokāms dizains",
  "_layout_default": "Noklusējuma izkārtojums",
  "_layout_layout1": "1. izkārtojums"
});