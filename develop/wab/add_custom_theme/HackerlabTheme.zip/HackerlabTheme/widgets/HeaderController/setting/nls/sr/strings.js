define({
  "group": "Naziv",
  "openAll": "Otvori sve u panelu",
  "dropDown": "Prikaži padajući meni",
  "noGroup": "Grupa vidžeta nije postavljena.",
  "groupSetLabel": "Postavi svojstva grupe vidžeta"
});