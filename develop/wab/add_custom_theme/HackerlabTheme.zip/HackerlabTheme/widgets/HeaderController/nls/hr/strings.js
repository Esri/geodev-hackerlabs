define({
  "_widgetLabel": "Kontroler zaglavlja",
  "signin": "Prijava",
  "signout": "Odjava",
  "about": "Informacije",
  "signInTo": "Prijavi se u",
  "cantSignOutTip": "Funkcija nije dostupna u načinu pretpregleda.",
  "more": "više"
});